﻿Public Class frmStoryboard

    Private Sub frmStoryboard_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ToolStrip1.Items.Clear()
        Dim j As Int32 = 0
        For Each li As ListViewItem In frmPictionary.lstSearch.Items
            Dim tsi As ToolStripItem = ToolStrip1.Items.Add(li.SubItems(1).Text)
            tsi.Image = Image.FromFile(Application.StartupPath & "\" & li.SubItems(5).Text)
            tsi.ToolTipText = "Index:" & li.SubItems.Item(0).Text & vbCrLf & "English:" & li.SubItems.Item(1).Text & vbCrLf & "Native:" & li.SubItems.Item(2).Text & vbCrLf & "Info:" & li.SubItems.Item(3).Text & vbCrLf & "Group:" & li.SubItems.Item(4).Text & vbCrLf & "Path:" & li.SubItems.Item(5).Text
        Next

    End Sub

    'Private ti As ToolStripItem

    'Private Sub ToolStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles ToolStrip1.ItemClicked
    '    ti = e.ClickedItem
    'End Sub

    'Private Sub ToolStrip1_PreviewKeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.PreviewKeyDownEventArgs) Handles ToolStrip1.PreviewKeyDown
    '    If e.KeyCode = Keys.Delete Then
    '        ToolStrip1.Items.Remove(ti)
    '    End If
    'End Sub


    Private Sub TrackBar1_ValueChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TrackBar1.ValueChanged
        ToolStrip1.ImageScalingSize = New Size(TrackBar1.Value, TrackBar1.Value)
        ToolStrip1.Width += 1
        ToolStrip1.Width -= 1

    End Sub
End Class