﻿Module modFriend
    Friend Structure GLYPH
        Public dwIndex As Int32
        Public EnglishText As String
        Public NativeText As String
        Public InfoText As String
        Public ImagePath As String
        Public Group As String
        Public Frequency As String
    End Structure
    Friend groupbyname As Boolean = False

    Friend DictionaryIndex As Int32 = 0
    'Friend spash As Boolean = True
    Friend Function LoadGlyphsFromFile(ByVal pth As String) As GLYPH()
        On Error Resume Next
        Dim cG(-1) As GLYPH
        If IO.File.Exists(pth) = False Then
            LoadGlyphsFromFile = cG
            Exit Function
        End If
        Dim sr As New IO.StreamReader(pth)
        Dim i As Int32 = 0

        Do
            If sr.EndOfStream = True Then Exit Do
            Dim inp As String = sr.ReadLine.Trim
            If inp.Trim <> "" Then
                Array.Resize(cG, cG.Length + 1)
                cG(cG.Length - 1).dwIndex = i
                Dim p() As String = inp.Split("|")
                If p.Length > 0 Then
                    cG(cG.Length - 1).EnglishText = p(0).ToLower.Replace(".", "").Replace("?", "").Replace(":", "").Trim
                    If p.Length > 1 Then
                        cG(cG.Length - 1).NativeText = p(1).ToLower.Replace(".", "").Replace("?", "").Replace(":", "").Trim
                        If p.Length > 2 Then
                            cG(cG.Length - 1).InfoText = p(2).Trim
                            If p.Length > 3 Then
                                cG(cG.Length - 1).ImagePath = p(3)     ' p(3) = Application.StartupPath & "\" & p(3)
                                If p.Length > 4 Then
                                    cG(cG.Length - 1).Group = p(4).Trim
                                    If p.Length > 5 Then
                                        cG(cG.Length - 1).Frequency = p(5).Trim
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
                i += 1
            End If
        Loop
        LoadGlyphsFromFile = cG
        sr.Close()
    End Function
    Friend Sub DeleteDictionaryItem(ByVal lpPath As String)
        Try
            Dim pth As String = Application.StartupPath & "\pictionary.txt"
            Dim pth2 As String = Application.StartupPath & "\pictionary2.txt"
            IO.File.Delete(pth2)
            Dim glyphs() As GLYPH = LoadGlyphsFromFile(pth)
            Dim bEditDelete As Boolean = False
            Dim bpath As Boolean = IO.File.Exists(lpPath.Trim)
            Dim i As Int32 = 0
            Dim rIndex As Int32

            Dim sw As New IO.StreamWriter(pth2)
            For j As Int32 = 0 To glyphs.Length - 1
                i += 1
                If bpath = True AndAlso lpPath.ToLower.Trim.IndexOf(glyphs(j).ImagePath.ToLower.Trim) <> -1 Then 'if an existing line matches the same glyph path being deleted
                    'skip writing to new raw file
                    rIndex = i

                Else 'otherwise just write the existing line to the new file
                    sw.WriteLine(glyphs(j).EnglishText & "|" & glyphs(j).NativeText & "|" & glyphs(j).InfoText & "|" & glyphs(j).ImagePath & "|" & glyphs(j).Group) '
                    sw.Flush()
                End If
            Next
            sw.Close()
            rIndex = New Random(Environment.TickCount).Next
            If IO.File.Exists(pth2) = True Then 'raw file exist
                'move to archive for non-desctructive safety
                If IO.Directory.Exists(Application.StartupPath & "\Archive") = False Then 'if archive directory does not exist then create it
                    IO.Directory.CreateDirectory(Application.StartupPath & "\Archive")
                End If
                If IO.Directory.Exists(Application.StartupPath & "\Archive") = True Then 'if it actually was created, then move file to it
                    Dim dest As String = Application.StartupPath & "\Archive\" & Now.ToString.Replace(" ", "-").Replace("/", "-").Replace(":", "-") & rIndex & "pictionary.txt"
                    IO.File.Move(pth, dest)
                End If
                'now copy
                IO.File.Copy(pth2, pth, True) 'copy new to old file spot
                If IO.File.Exists(pth) = True Then 'if new file has replaced old successfully
                    IO.File.Delete(pth2) 'only then delete the raw generation
                End If
            End If
            'frmPictionary.RemoveDictionaryItem(rIndex - 1)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
End Module
